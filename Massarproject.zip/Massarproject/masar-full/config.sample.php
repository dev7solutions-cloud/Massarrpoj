<?php
return [
    'host' => 'sql301.infinityfree.com',
    'database' => 'if0_43142587_campus_bus',
    'username' => 'if0_43142587',
    'password' => 'yylmVuHDGvAX',
];
